export default function ResultOverlay({ result, onClose, onViewListings }) {
  const { score, verdict, signals = {}, reasoning } = result;

  const scoreColor = score >= 80 ? "var(--green)" : score >= 50 ? "var(--amber)" : "var(--red)";

  const verdictConfig = {
    approved: { style: { background: "var(--green-bg)", color: "var(--green)" }, label: "✓ Automatically Approved", subtitle: "Listing is live and published" },
    flagged:  { style: { background: "var(--amber-bg)", color: "var(--amber)" }, label: "⚠ Flagged for Manual Review", subtitle: "A reviewer will inspect this listing" },
    rejected: { style: { background: "var(--red-bg)", color: "var(--red)" }, label: "✗ Rejected", subtitle: "Listing did not pass authenticity check" },
  }[verdict] || { style: {}, label: "Unknown", subtitle: "" };

  const signalDefs = [
    { label: "Consistency", value: signals.consistency ?? 50 },
    { label: "Authenticity", value: signals.authenticity ?? 50 },
    { label: "Originality", value: 100 - (signals.reuse_risk ?? 50) },
    { label: "Photo Quality", value: signals.quality ?? 50 },
  ];

  function signalColor(v) {
    return v >= 70 ? "var(--green)" : v >= 45 ? "var(--amber)" : "var(--red)";
  }

  return (
    <div className="result-overlay">
      <div className="result-box">
        <button className="result-close" onClick={onClose}>✕</button>

        <div className="result-score-circle" style={{ borderColor: scoreColor }}>
          <div className="score-circle-num" style={{ color: scoreColor }}>{score}</div>
          <div className="score-circle-pct">/ 100</div>
        </div>

        <div className="result-verdict">
          <div className="verdict-badge" style={verdictConfig.style}>{verdictConfig.label}</div>
          <div className="verdict-title">{verdictConfig.subtitle}</div>
        </div>

        <div className="signals-grid">
          {signalDefs.map((s) => (
            <div className="signal-card" key={s.label}>
              <div className="signal-name">{s.label}</div>
              <div className="signal-val" style={{ color: signalColor(s.value) }}>{s.value}%</div>
              <div className="signal-bar">
                <div className="signal-fill" style={{ width: `${s.value}%`, background: signalColor(s.value) }} />
              </div>
            </div>
          ))}
        </div>

        <div className="result-reason">
          <div className="result-reason-title">Agent Reasoning</div>
          <div className="result-reason-text">{reasoning || "No reasoning provided."}</div>
        </div>

        <div className="result-actions">
          <button className="btn-secondary" onClick={onClose}>Close</button>
          <button className="btn-primary-full" onClick={onViewListings}>View in Listings →</button>
        </div>
      </div>
    </div>
  );
}
