import { useState, useEffect } from "react";

const STEPS = [
  "Extracting image metadata",
  "Checking cross-image consistency",
  "Detecting AI-generated content",
  "Scoring authenticity signals",
  "Generating verdict",
];

export default function AnalyzingOverlay() {
  const [current, setCurrent] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrent((prev) => (prev < STEPS.length - 1 ? prev + 1 : prev));
    }, 1200);
    return () => clearInterval(interval);
  }, []);

  const progress = ((current + 1) / STEPS.length) * 90;

  return (
    <div className="overlay">
      <div className="analyze-box">
        <div className="analyze-icon">🤖</div>
        <div className="analyze-title">AI Agent Running</div>
        <div className="analyze-sub">Analyzing your listing media for authenticity...</div>
        <div className="analyze-steps">
          {STEPS.map((step, i) => (
            <div key={i} className={`analyze-step ${i < current ? "done" : i === current ? "active" : ""}`}>
              <div className="step-dot" />
              {step}
            </div>
          ))}
        </div>
        <div className="analyze-bar">
          <div className="analyze-fill" style={{ width: `${progress}%` }} />
        </div>
      </div>
    </div>
  );
}
