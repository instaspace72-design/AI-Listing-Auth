import { useState } from "react";

export default function ListingsPage({ listings }) {
  const [filter, setFilter] = useState("all");

  const filtered = filter === "all" ? listings : listings.filter((l) => l.verdict === filter);
  const approved = listings.filter((l) => l.verdict === "approved").length;
  const flagged = listings.filter((l) => l.verdict === "flagged" || l.verdict === "rejected").length;

  function scoreClass(l) {
    if (l.verdict === "pending") return "pending";
    return l.score >= 80 ? "green" : l.score >= 50 ? "amber" : "red";
  }

  function badgeClass(verdict) {
    return { approved: "badge-approved", flagged: "badge-flagged", rejected: "badge-rejected", pending: "badge-pending" }[verdict] || "badge-pending";
  }

  function badgeLabel(verdict) {
    return { approved: "✓ Approved", flagged: "⚠ Flagged", rejected: "✗ Rejected", pending: "⏳ Analyzing..." }[verdict] || "Pending";
  }

  return (
    <div>
      <div className="hero">
        <div className="hero-tag"><span className="pulse" /> AI Authenticity Agent Active</div>
        <h1>Real listings.<br /><em>Verified automatically.</em></h1>
        <p>Every listing is analyzed by our AI agent — checking image consistency, detecting AI-generated media, and scoring authenticity before going live.</p>
        <div className="hero-stats">
          <div className="stat"><div className="stat-num">{listings.length}</div><div className="stat-label">Total Listings</div></div>
          <div className="stat"><div className="stat-num">{approved}</div><div className="stat-label">Auto Approved</div></div>
          <div className="stat"><div className="stat-num">{flagged}</div><div className="stat-label">Flagged / Rejected</div></div>
        </div>
      </div>

      <div className="section-hdr">
        <div className="section-title">All Listings</div>
        <div className="filter-row">
          {["all","approved","flagged","rejected"].map((f) => (
            <button key={f} className={`filter-btn ${filter === f ? "active" : ""}`} onClick={() => setFilter(f)}>
              {f === "all" ? "All" : f === "approved" ? "✓ Approved" : f === "flagged" ? "⚠ Flagged" : "✗ Rejected"}
            </button>
          ))}
        </div>
      </div>

      {filtered.length === 0 ? (
        <div className="empty">
          <div className="empty-icon">🏠</div>
          <p>{filter === "all" ? "No listings yet.\nAdd your first listing to see the AI agent in action." : `No ${filter} listings yet.`}</p>
        </div>
      ) : (
        <div className="listings-grid">
          {filtered.map((l) => (
            <div className="listing-card" key={l.id}>
              <div className="card-img-wrap">
                {l.images && l.images.length > 0
                  ? <img src={l.images[0]} alt={l.title} />
                  : <div className="card-img-placeholder"><span style={{fontSize:36}}>🏠</span><span>No image</span></div>
                }
                <div className={`score-badge ${badgeClass(l.verdict)}`}>{badgeLabel(l.verdict)}</div>
              </div>
              <div className="card-body">
                <div className="card-title">{l.title}</div>
                <div className="card-loc">📍 {l.location}</div>
                <div className="card-price">{l.price}</div>
                <div className="card-meta">
                  <span className="score-label">Authenticity Score</span>
                  <span className={`score-val ${scoreClass(l)}`}>
                    {l.verdict === "pending" ? "Analyzing..." : `${l.score}%`}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
