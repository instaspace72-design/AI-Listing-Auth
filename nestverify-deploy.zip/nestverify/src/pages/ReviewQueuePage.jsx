export default function ReviewQueuePage({ listings, onAction }) {
  const flagged = listings.filter((l) => l.verdict === "flagged");

  if (flagged.length === 0) {
    return (
      <div>
        <div className="section-hdr"><div className="section-title">Manual Review Queue</div></div>
        <div className="empty"><div className="empty-icon">✅</div><p>No listings pending review.<br />Flagged listings will appear here automatically.</p></div>
      </div>
    );
  }

  return (
    <div>
      <div className="section-hdr">
        <div className="section-title">Manual Review Queue</div>
        <span style={{fontSize:13,color:"var(--text3)"}}>{flagged.length} listing{flagged.length !== 1 ? "s" : ""} awaiting review</span>
      </div>
      <div className="queue-list">
        {flagged.map((l) => (
          <div className="queue-item" key={l.id}>
            <div className="queue-thumb">
              {l.images && l.images.length > 0
                ? <img src={l.images[0]} alt={l.title} />
                : "🏠"
              }
            </div>
            <div className="queue-info">
              <div className="queue-name">{l.title}</div>
              <div className="queue-reason">📍 {l.location} · Score: {l.score}% · {l.reasoning ? l.reasoning.substring(0, 100) + "..." : "Awaiting AI review"}</div>
            </div>
            <div className="queue-score">{l.score}%</div>
            <div className="queue-actions">
              <button className="btn-approve" onClick={() => onAction(l.id, "approved")}>✓ Approve</button>
              <button className="btn-reject" onClick={() => onAction(l.id, "rejected")}>✗ Reject</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
