import { useState, useRef } from "react";

export default function AddListingPage({ onSubmit }) {
  const [apiKey, setApiKey] = useState(() => localStorage.getItem("nv_apikey") || "");
  const [title, setTitle] = useState("");
  const [location, setLocation] = useState("");
  const [price, setPrice] = useState("");
  const [description, setDescription] = useState("");
  const [images, setImages] = useState([]);
  const [dragging, setDragging] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const fileRef = useRef();

  function handleFiles(files) {
    const remaining = 5 - images.length;
    const toAdd = Array.from(files).slice(0, remaining);
    toAdd.forEach((file) => {
      const reader = new FileReader();
      reader.onload = (e) => setImages((prev) => [...prev, e.target.result].slice(0, 5));
      reader.readAsDataURL(file);
    });
  }

  function removeImage(i) {
    setImages((prev) => prev.filter((_, idx) => idx !== i));
  }

  async function handleSubmit() {
    if (!title.trim() || !location.trim() || !price.trim()) { alert("Please fill in Title, Location, and Price."); return; }
    if (!apiKey.trim()) { alert("Please enter your Anthropic API key to run the AI analysis."); return; }
    localStorage.setItem("nv_apikey", apiKey);
    setSubmitting(true);
    await onSubmit({ title: title.trim(), location: location.trim(), price: price.trim(), description: description.trim(), images, apiKey: apiKey.trim() });
    setTitle(""); setLocation(""); setPrice(""); setDescription(""); setImages([]);
    setSubmitting(false);
  }

  return (
    <div className="form-card">
      <div className="form-title">Add New Listing</div>
      <div className="form-sub">Upload property images and our AI agent will automatically verify authenticity, detect fake or AI-generated media, and assign a trust score.</div>

      <div className="api-key-row">
        <span>🔑</span>
        <input
          type="password"
          placeholder="Paste your Anthropic API key (sk-ant-...)"
          value={apiKey}
          onChange={(e) => setApiKey(e.target.value)}
          autoComplete="off"
        />
      </div>
      <div className="api-notice">
        Get your free key at <a href="https://console.anthropic.com" target="_blank" rel="noreferrer">console.anthropic.com</a> · ~$0.003 per analysis · Key is saved locally in your browser only.
      </div>

      <div className="form-group">
        <label className="form-label">Property Title *</label>
        <input className="form-input" placeholder="e.g. Cozy 2BR Apartment in Gulberg, Lahore" value={title} onChange={(e) => setTitle(e.target.value)} />
      </div>

      <div className="form-row">
        <div className="form-group">
          <label className="form-label">Location *</label>
          <input className="form-input" placeholder="City, Area" value={location} onChange={(e) => setLocation(e.target.value)} />
        </div>
        <div className="form-group">
          <label className="form-label">Price / month *</label>
          <input className="form-input" placeholder="e.g. PKR 45,000" value={price} onChange={(e) => setPrice(e.target.value)} />
        </div>
      </div>

      <div className="form-group">
        <label className="form-label">Description</label>
        <textarea className="form-input" placeholder="Describe the property — rooms, amenities, nearby landmarks..." value={description} onChange={(e) => setDescription(e.target.value)} />
      </div>

      <div className="form-group">
        <label className="form-label">Upload Images * (up to 5 — AI analyzes all together)</label>
        <div
          className={`upload-zone ${dragging ? "dragging" : ""}`}
          onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
          onDragLeave={() => setDragging(false)}
          onDrop={(e) => { e.preventDefault(); setDragging(false); handleFiles(e.dataTransfer.files); }}
          onClick={() => fileRef.current.click()}
        >
          <input ref={fileRef} type="file" accept="image/*" multiple style={{display:"none"}} onChange={(e) => handleFiles(e.target.files)} />
          <div className="upload-icon">📸</div>
          <div className="upload-text">Drag & drop images or click to browse</div>
          <div className="upload-hint">JPG, PNG, WEBP · Max 5 images · {5 - images.length} remaining</div>
        </div>
        {images.length > 0 && (
          <div className="previews">
            {images.map((src, i) => (
              <div className="preview-wrap" key={i}>
                <img src={src} alt={`preview ${i + 1}`} />
                <button className="preview-del" onClick={() => removeImage(i)}>✕</button>
              </div>
            ))}
          </div>
        )}
      </div>

      <button className="btn-primary" onClick={handleSubmit} disabled={submitting}>
        {submitting ? "Submitting..." : "Submit & Run AI Analysis →"}
      </button>
    </div>
  );
}
