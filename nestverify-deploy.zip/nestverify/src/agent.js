export async function runAIAgent(apiKey, title, description, images) {
  const imageContent = images.map((img) => ({
    type: "image",
    source: {
      type: "base64",
      media_type: img.split(";")[0].split(":")[1],
      data: img.split(",")[1],
    },
  }));

  const prompt = `You are a professional real estate listing authenticity agent. Analyze the uploaded images for the property titled "${title}".
${description ? `Property description: "${description}"` : ""}

Your tasks:
1. Determine if ALL images appear to show the SAME real physical property (consistency check)
2. Detect any signs of AI-generated imagery, deepfakes, or digital manipulation
3. Check if images appear to be stock photos or reused from other sources
4. Assess overall photo authenticity and quality

Return ONLY a valid JSON object — no markdown, no extra text, just raw JSON:
{
  "score": <integer 0-100, overall authenticity score>,
  "verdict": "<approved|flagged|rejected>",
  "signals": {
    "consistency": <0-100, all images same place?>,
    "authenticity": <0-100, genuine real photos vs AI/manipulated?>,
    "reuse_risk": <0-100, higher = more likely stock/reused>,
    "quality": <0-100, photo quality and professionalism>
  },
  "reasoning": "<2-3 sentences explaining your findings and score>"
}

Verdict rules:
- score >= 80 → "approved" (auto-publish)
- score 50-79 → "flagged" (manual review)
- score < 50 → "rejected"

If no images provided, assign score 25 and verdict "flagged" with appropriate reasoning.`;

  const userContent =
    imageContent.length > 0
      ? [...imageContent, { type: "text", text: prompt }]
      : [{ type: "text", text: prompt }];

  const response = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": apiKey,
      "anthropic-version": "2023-06-01",
      "anthropic-dangerous-direct-browser-access": "true",
    },
    body: JSON.stringify({
      model: "claude-sonnet-4-20250514",
      max_tokens: 1000,
      messages: [{ role: "user", content: userContent }],
    }),
  });

  if (!response.ok) {
    const errData = await response.json().catch(() => ({}));
    throw new Error(errData.error?.message || `API error ${response.status}`);
  }

  const data = await response.json();
  const rawText = data.content
    .map((c) => c.text || "")
    .join("")
    .trim();

  const clean = rawText.replace(/```json|```/g, "").trim();
  const parsed = JSON.parse(clean);

  // Enforce verdict based on score
  if (parsed.score >= 80) parsed.verdict = "approved";
  else if (parsed.score >= 50) parsed.verdict = "flagged";
  else parsed.verdict = "rejected";

  return parsed;
}
