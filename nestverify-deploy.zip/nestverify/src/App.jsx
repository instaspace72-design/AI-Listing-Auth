import { useState, useEffect } from "react";
import ListingsPage from "./pages/ListingsPage";
import AddListingPage from "./pages/AddListingPage";
import ReviewQueuePage from "./pages/ReviewQueuePage";
import AnalyzingOverlay from "./components/AnalyzingOverlay";
import ResultOverlay from "./components/ResultOverlay";
import { runAIAgent } from "./agent";
import "./index.css";

export default function App() {
  const [page, setPage] = useState("listings");
  const [listings, setListings] = useState(() => {
    try { return JSON.parse(localStorage.getItem("nv_listings") || "[]"); } catch { return []; }
  });
  const [analyzing, setAnalyzing] = useState(false);
  const [result, setResult] = useState(null);

  useEffect(() => {
    localStorage.setItem("nv_listings", JSON.stringify(listings));
  }, [listings]);

  const flaggedCount = listings.filter((l) => l.verdict === "flagged").length;

  async function handleSubmit(formData) {
    const newListing = {
      id: Date.now(),
      ...formData,
      verdict: "pending",
      score: 0,
      signals: {},
      reasoning: "",
      createdAt: new Date().toISOString(),
    };
    setListings((prev) => [newListing, ...prev]);
    setAnalyzing(true);
    setPage("listings");

    try {
      const agentResult = await runAIAgent(
        formData.apiKey,
        formData.title,
        formData.description,
        formData.images
      );
      setListings((prev) =>
        prev.map((l) =>
          l.id === newListing.id ? { ...l, ...agentResult } : l
        )
      );
      setResult({ ...newListing, ...agentResult });
    } catch (err) {
      const fallback = {
        score: 0,
        verdict: "flagged",
        signals: { consistency: 0, authenticity: 0, reuse_risk: 100, quality: 0 },
        reasoning: "AI analysis failed: " + err.message + ". Listing flagged for manual review.",
      };
      setListings((prev) =>
        prev.map((l) => (l.id === newListing.id ? { ...l, ...fallback } : l))
      );
      setResult({ ...newListing, ...fallback });
    } finally {
      setAnalyzing(false);
    }
  }

  function handleQueueAction(id, action) {
    setListings((prev) =>
      prev.map((l) => (l.id === id ? { ...l, verdict: action } : l))
    );
  }

  return (
    <div className="app">
      <nav className="nav">
        <div className="nav-logo">Nest<span>Verify</span></div>
        <div className="nav-tabs">
          <button className={`nav-tab ${page === "listings" ? "active" : ""}`} onClick={() => setPage("listings")}>Listings</button>
          <button className={`nav-tab ${page === "add" ? "active" : ""}`} onClick={() => setPage("add")}>+ Add Listing</button>
          <button className={`nav-tab ${page === "review" ? "active" : ""}`} onClick={() => setPage("review")}>
            Review Queue {flaggedCount > 0 && <span className="queue-badge">{flaggedCount}</span>}
          </button>
        </div>
      </nav>

      <main>
        {page === "listings" && <ListingsPage listings={listings} />}
        {page === "add" && <AddListingPage onSubmit={handleSubmit} onNavigate={setPage} />}
        {page === "review" && <ReviewQueuePage listings={listings} onAction={handleQueueAction} />}
      </main>

      {analyzing && <AnalyzingOverlay />}
      {result && <ResultOverlay result={result} onClose={() => setResult(null)} onViewListings={() => { setResult(null); setPage("listings"); }} />}
    </div>
  );
}
